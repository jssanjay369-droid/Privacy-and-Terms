package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "trace_records")
data class TraceRecord(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val traceType: String, // "PHONE_NETWORK" or "EMAIL_PATHWAY"
    val target: String,
    val timestamp: Long = System.currentTimeMillis(),
    val totalHops: Int,
    val avgLatencyMs: Double,
    val packetLossPercent: Double,
    val status: String, // "COMPLETED", "IN_PROGRESS", "FAILED"
    val summaryText: String
)

@Entity(tableName = "hop_records")
data class HopDetailRecord(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val traceRecordId: Int,
    val hopIndex: Int,
    val ipAddress: String,
    val hostname: String,
    val rttMs: Long,
    val packetLossPercent: Double,
    val locationName: String,
    val ispOrOrg: String,
    val nodeType: String, // "DEVICE", "GATEWAY", "ISP_ROUTER", "TRANSIT_BACKBONE", "MX_SERVER", "STORAGE"
    val securityStatus: String, // "SECURE", "WARNING", "ALERT", "NEUTRAL"
    val details: String
)
