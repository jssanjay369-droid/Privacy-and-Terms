package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface TraceDao {

    @Query("SELECT * FROM trace_records ORDER BY timestamp DESC")
    fun getAllTraces(): Flow<List<TraceRecord>>

    @Query("SELECT * FROM trace_records WHERE id = :traceId")
    suspend fun getTraceById(traceId: Int): TraceRecord?

    @Query("SELECT * FROM hop_records WHERE traceRecordId = :traceId ORDER BY hopIndex ASC")
    fun getHopsForTrace(traceId: Int): Flow<List<HopDetailRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrace(record: TraceRecord): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHops(hops: List<HopDetailRecord>)

    @Query("DELETE FROM trace_records WHERE id = :traceId")
    suspend fun deleteTrace(traceId: Int)

    @Query("DELETE FROM hop_records WHERE traceRecordId = :traceId")
    suspend fun deleteHopsForTrace(traceId: Int)

    @Query("DELETE FROM trace_records")
    suspend fun deleteAllTraces()

    @Query("DELETE FROM hop_records")
    suspend fun deleteAllHops()
}
