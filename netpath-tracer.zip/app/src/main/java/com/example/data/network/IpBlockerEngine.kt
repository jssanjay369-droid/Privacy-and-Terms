package com.example.data.network

import java.net.InetAddress

data class IpBlockRule(
    val id: String = java.util.UUID.randomUUID().toString(),
    val ipOrCidr: String,
    val label: String,
    val isEnabled: Boolean = true,
    var blockedCount: Int = 0,
    val addedTimestamp: Long = System.currentTimeMillis()
)

data class BlockedProbeLog(
    val id: String = java.util.UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val sourceIp: String,
    val targetHostOrEmail: String,
    val actionTaken: String,
    val ruleMatched: String
)

class IpBlockerEngine {

    var isIpBlockerActive: Boolean = true
    var isTraceConnectionBlockerActive: Boolean = true

    private val rules = mutableListOf(
        IpBlockRule(
            ipOrCidr = "185.220.101.5",
            label = "Known Malicious Tor Exit Node",
            isEnabled = true,
            blockedCount = 14
        ),
        IpBlockRule(
            ipOrCidr = "198.51.100.0/24",
            label = "Unsolicited Probe Scanner Subnet",
            isEnabled = true,
            blockedCount = 8
        ),
        IpBlockRule(
            ipOrCidr = "104.28.194.22",
            label = "Suspicious Proxy Transit Route",
            isEnabled = true,
            blockedCount = 3
        ),
        IpBlockRule(
            ipOrCidr = "203.0.113.42",
            label = "Unauthorized Port Scanner",
            isEnabled = true,
            blockedCount = 21
        )
    )

    private val blockedLogs = mutableListOf<BlockedProbeLog>()

    fun getRules(): List<IpBlockRule> = rules.toList()

    fun getLogs(): List<BlockedProbeLog> = blockedLogs.toList()

    fun addRule(ipOrCidr: String, label: String) {
        val clean = ipOrCidr.trim()
        if (clean.isNotEmpty()) {
            rules.add(0, IpBlockRule(ipOrCidr = clean, label = if (label.isBlank()) "Custom User Firewall Rule" else label))
        }
    }

    fun removeRule(ruleId: String) {
        rules.removeAll { it.id == ruleId }
    }

    fun toggleRule(ruleId: String) {
        val index = rules.indexOfFirst { it.id == ruleId }
        if (index != -1) {
            val r = rules[index]
            rules[index] = r.copy(isEnabled = !r.isEnabled)
        }
    }

    fun isIpBlocked(ip: String): Pair<Boolean, IpBlockRule?> {
        if (!isIpBlockerActive) return Pair(false, null)

        for (rule in rules) {
            if (!rule.isEnabled) continue
            if (matchesIpOrCidr(ip, rule.ipOrCidr)) {
                rule.blockedCount++
                return Pair(true, rule)
            }
        }
        return Pair(false, null)
    }

    fun recordBlockedLog(sourceIp: String, target: String, action: String, ruleLabel: String) {
        val log = BlockedProbeLog(
            sourceIp = sourceIp,
            targetHostOrEmail = target,
            actionTaken = action,
            ruleMatched = ruleLabel
        )
        blockedLogs.add(0, log)
        if (blockedLogs.size > 50) {
            blockedLogs.removeAt(blockedLogs.size - 1)
        }
    }

    private fun matchesIpOrCidr(ip: String, ruleStr: String): Boolean {
        if (ip == ruleStr) return true
        if (ruleStr.contains("/")) {
            try {
                val parts = ruleStr.split("/")
                val baseIp = parts[0]
                val prefix = parts[1].toIntOrNull() ?: 24
                
                val ipParts = ip.split(".").mapNotNull { it.toIntOrNull() }
                val baseParts = baseIp.split(".").mapNotNull { it.toIntOrNull() }
                
                if (ipParts.size == 4 && baseParts.size == 4) {
                    if (prefix >= 24) {
                        return ipParts[0] == baseParts[0] && ipParts[1] == baseParts[1] && ipParts[2] == baseParts[2]
                    } else if (prefix >= 16) {
                        return ipParts[0] == baseParts[0] && ipParts[1] == baseParts[1]
                    } else if (prefix >= 8) {
                        return ipParts[0] == baseParts[0]
                    }
                }
            } catch (e: Exception) {
                // Ignore parsing errors
            }
        }
        return false
    }
}
