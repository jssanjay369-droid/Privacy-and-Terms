package com.example.data.db

import kotlinx.coroutines.flow.Flow

class TraceRepository(private val traceDao: TraceDao) {

    val allTraces: Flow<List<TraceRecord>> = traceDao.getAllTraces()

    fun getHopsForTrace(traceId: Int): Flow<List<HopDetailRecord>> {
        return traceDao.getHopsForTrace(traceId)
    }

    suspend fun saveTraceRun(trace: TraceRecord, hops: List<HopDetailRecord>): Long {
        val traceId = traceDao.insertTrace(trace)
        val updatedHops = hops.map { it.copy(traceRecordId = traceId.toInt()) }
        traceDao.insertHops(updatedHops)
        return traceId
    }

    suspend fun deleteTrace(traceId: Int) {
        traceDao.deleteHopsForTrace(traceId)
        traceDao.deleteTrace(traceId)
    }

    suspend fun clearHistory() {
        traceDao.deleteAllHops()
        traceDao.deleteAllTraces()
    }
}
