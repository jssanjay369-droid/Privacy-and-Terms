package com.example.data.network

data class HopNode(
    val hopIndex: Int,
    val ipAddress: String,
    val hostname: String,
    val rttMs: Long,
    val packetLossPercent: Double,
    val locationName: String,
    val ispOrOrg: String,
    val nodeType: NodeType,
    val securityStatus: SecurityStatus,
    val details: String = ""
)

enum class NodeType {
    DEVICE,
    GATEWAY,
    ISP_ROUTER,
    TRANSIT_BACKBONE,
    MX_SERVER,
    STORAGE,
    FIREWALL_BLOCKED,
    UNKNOWN
}

enum class SecurityStatus {
    SECURE,
    WARNING,
    ALERT,
    NEUTRAL
}

data class DeviceNetworkInfo(
    val localIp: String = "192.168.1.105",
    val gatewayIp: String = "192.168.1.1",
    val publicIp: String = "Fetching...",
    val interfaceName: String = "wlan0",
    val connectionType: String = "Wi-Fi 6",
    val signalStrengthDbm: Int = -58,
    val carrierOrIsp: String = "Local Network / ISP",
    val dnsServers: List<String> = listOf("8.8.8.8", "1.1.1.1"),
    val cityRegionCountry: String = "Detecting location..."
)

data class EmailPathwayInfo(
    val emailAddress: String,
    val domain: String,
    val mxServers: List<MxNode>,
    val spfRecord: String,
    val dmarcRecord: String,
    val isSpfValid: Boolean,
    val isDmarcValid: Boolean,
    val tlsSupport: String, // "TLS 1.3 Strict", "TLS 1.2", "No Enforced TLS"
    val hops: List<HopNode>,
    val overallSecurityScore: Int // 0 to 100
)

data class MxNode(
    val priority: Int,
    val host: String,
    val ipAddress: String,
    val port: Int = 25,
    val latencyMs: Long = 24,
    val provider: String = "Email Service Provider"
)
