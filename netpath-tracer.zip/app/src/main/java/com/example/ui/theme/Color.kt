package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberCyan = Color(0xFF00F5D4)
val ElectricBlue = Color(0xFF00B4D8)
val DeepNavyBg = Color(0xFF0B132B)
val SurfaceDarkCard = Color(0xFF1C2541)
val SurfaceDarkElevated = Color(0xFF2E3D52)

val EmeraldGreen = Color(0xFF10B981)
val AmberYellow = Color(0xFFF59E0B)
val CrimsonRed = Color(0xFFEF4444)

val TechLightBg = Color(0xFFF0F4F8)
val TechLightSurface = Color(0xFFFFFFFF)
val TechLightPrimary = Color(0xFF0077B6)
val TechLightSecondary = Color(0xFF0096C7)
