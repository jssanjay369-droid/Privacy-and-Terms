package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.db.HopDetailRecord
import com.example.data.db.TraceRecord
import com.example.data.db.TraceRepository
import com.example.data.network.BlockedProbeLog
import com.example.data.network.DeviceNetworkInfo
import com.example.data.network.EmailPathwayEngine
import com.example.data.network.EmailPathwayInfo
import com.example.data.network.HopNode
import com.example.data.network.IpBlockRule
import com.example.data.network.IpBlockerEngine
import com.example.data.network.NetworkTracerouteEngine
import com.example.data.network.NodeType
import com.example.data.network.SecurityStatus
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class TraceType {
    PHONE_NETWORK,
    EMAIL_PATHWAY
}

class TracerouteViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        const val PRO_USER_EMAIL = "jssanjay369@gmail.com"
    }

    private val db = AppDatabase.getDatabase(application)
    private val repository = TraceRepository(db.traceDao())
    private val tracerouteEngine = NetworkTracerouteEngine(application)
    private val emailPathwayEngine = EmailPathwayEngine(tracerouteEngine)
    val ipBlockerEngine = IpBlockerEngine()

    private var traceJob: Job? = null

    // Account & Pro Status State
    val currentUserEmail = MutableStateFlow(PRO_USER_EMAIL)
    private val _isProUser = MutableStateFlow(true)
    val isProUser: StateFlow<Boolean> = _isProUser.asStateFlow()

    // Blocker States
    private val _isIpBlockerActive = MutableStateFlow(true)
    val isIpBlockerActive: StateFlow<Boolean> = _isIpBlockerActive.asStateFlow()

    private val _isTraceConnectionBlockerActive = MutableStateFlow(true)
    val isTraceConnectionBlockerActive: StateFlow<Boolean> = _isTraceConnectionBlockerActive.asStateFlow()

    private val _blockRules = MutableStateFlow<List<IpBlockRule>>(ipBlockerEngine.getRules())
    val blockRules: StateFlow<List<IpBlockRule>> = _blockRules.asStateFlow()

    private val _blockLogs = MutableStateFlow<List<BlockedProbeLog>>(ipBlockerEngine.getLogs())
    val blockLogs: StateFlow<List<BlockedProbeLog>> = _blockLogs.asStateFlow()

    // General App State
    private val _deviceNetworkInfo = MutableStateFlow(DeviceNetworkInfo())
    val deviceNetworkInfo: StateFlow<DeviceNetworkInfo> = _deviceNetworkInfo.asStateFlow()

    private val _selectedTab = MutableStateFlow(0) // 0: Phone, 1: Email, 2: Visualizer, 3: Security & Blocker, 4: History & Pro
    val selectedTab: StateFlow<Int> = _selectedTab.asStateFlow()

    private val _activeTraceType = MutableStateFlow(TraceType.PHONE_NETWORK)
    val activeTraceType: StateFlow<TraceType> = _activeTraceType.asStateFlow()

    val targetPhoneHost = MutableStateFlow("google.com")
    val targetEmailInput = MutableStateFlow("jssanjay369@gmail.com")

    private val _isTracing = MutableStateFlow(false)
    val isTracing: StateFlow<Boolean> = _isTracing.asStateFlow()

    private val _currentHops = MutableStateFlow<List<HopNode>>(emptyList())
    val currentHops: StateFlow<List<HopNode>> = _currentHops.asStateFlow()

    private val _emailPathwayInfo = MutableStateFlow<EmailPathwayInfo?>(null)
    val emailPathwayInfo: StateFlow<EmailPathwayInfo?> = _emailPathwayInfo.asStateFlow()

    private val _selectedHopForDetail = MutableStateFlow<HopNode?>(null)
    val selectedHopForDetail: StateFlow<HopNode?> = _selectedHopForDetail.asStateFlow()

    private val _exportText = MutableStateFlow<String?>(null)
    val exportText: StateFlow<String?> = _exportText.asStateFlow()

    val savedTraces: StateFlow<List<TraceRecord>> = repository.allTraces.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private val _historyHops = MutableStateFlow<List<HopDetailRecord>>(emptyList())
    val historyHops: StateFlow<List<HopDetailRecord>> = _historyHops.asStateFlow()

    init {
        refreshDeviceInfo()
        checkProStatus()
    }

    fun setUserEmail(email: String) {
        currentUserEmail.value = email.trim()
        checkProStatus()
    }

    private fun checkProStatus() {
        _isProUser.value = currentUserEmail.value.equals(PRO_USER_EMAIL, ignoreCase = true)
    }

    fun setTab(index: Int) {
        _selectedTab.value = index
    }

    fun setTraceType(type: TraceType) {
        _activeTraceType.value = type
    }

    fun toggleIpBlocker() {
        if (!_isProUser.value) return // Pro feature lock
        val newValue = !_isIpBlockerActive.value
        _isIpBlockerActive.value = newValue
        ipBlockerEngine.isIpBlockerActive = newValue
    }

    fun toggleTraceConnectionBlocker() {
        if (!_isProUser.value) return // Pro feature lock
        val newValue = !_isTraceConnectionBlockerActive.value
        _isTraceConnectionBlockerActive.value = newValue
        ipBlockerEngine.isTraceConnectionBlockerActive = newValue
    }

    fun addBlockRule(ipOrCidr: String, label: String) {
        if (!_isProUser.value) return // Pro feature lock
        ipBlockerEngine.addRule(ipOrCidr, label)
        _blockRules.value = ipBlockerEngine.getRules()
    }

    fun removeBlockRule(ruleId: String) {
        if (!_isProUser.value) return // Pro feature lock
        ipBlockerEngine.removeRule(ruleId)
        _blockRules.value = ipBlockerEngine.getRules()
    }

    fun toggleBlockRule(ruleId: String) {
        if (!_isProUser.value) return // Pro feature lock
        ipBlockerEngine.toggleRule(ruleId)
        _blockRules.value = ipBlockerEngine.getRules()
    }

    fun refreshDeviceInfo() {
        viewModelScope.launch {
            val info = tracerouteEngine.getDeviceNetworkInfo()
            _deviceNetworkInfo.value = info
        }
    }

    fun startTrace() {
        if (_isTracing.value) return
        traceJob?.cancel()

        _isTracing.value = true
        _currentHops.value = emptyList()

        val type = _activeTraceType.value
        val target = if (type == TraceType.PHONE_NETWORK) targetPhoneHost.value else targetEmailInput.value
        val isPro = _isProUser.value

        traceJob = viewModelScope.launch {
            try {
                if (type == TraceType.PHONE_NETWORK) {
                    var hopCount = 0
                    tracerouteEngine.traceRouteToHost(target).collect { rawHop ->
                        hopCount++

                        // Check Basic Version Lock (Max 3 Hops)
                        if (!isPro && hopCount > 3) {
                            val lockedHop = HopNode(
                                hopIndex = hopCount,
                                ipAddress = "PRO.LOCKED",
                                hostname = "PRO VERSION FEATURE LOCKED",
                                rttMs = 0,
                                packetLossPercent = 100.0,
                                locationName = "Upgrade Required",
                                ispOrOrg = "Locked for Basic Users",
                                nodeType = NodeType.FIREWALL_BLOCKED,
                                securityStatus = SecurityStatus.ALERT,
                                details = "Hops 4-30 are locked in Basic Version. Switch user email to jssanjay369@gmail.com to unlock PRO VERSION!"
                            )
                            _currentHops.value = _currentHops.value + lockedHop
                            return@collect
                        }

                        // Check IP Blocker
                        val (isBlocked, rule) = ipBlockerEngine.isIpBlocked(rawHop.ipAddress)
                        val finalHop = if (isBlocked && rule != null) {
                            ipBlockerEngine.recordBlockedLog(
                                sourceIp = rawHop.ipAddress,
                                target = target,
                                action = "IP BLOCKER FIREWALL INTERCEPT",
                                ruleLabel = rule.label
                            )
                            _blockLogs.value = ipBlockerEngine.getLogs()
                            _blockRules.value = ipBlockerEngine.getRules()

                            HopNode(
                                hopIndex = rawHop.hopIndex,
                                ipAddress = rawHop.ipAddress,
                                hostname = "[BLOCKED BY IP FIREWALL]",
                                rttMs = 0,
                                packetLossPercent = 100.0,
                                locationName = "Blocked Node",
                                ispOrOrg = rule.label,
                                nodeType = NodeType.FIREWALL_BLOCKED,
                                securityStatus = SecurityStatus.ALERT,
                                details = "Blocked by Local IP Blocker Rule: ${rule.ipOrCidr} (${rule.label})"
                            )
                        } else {
                            rawHop
                        }

                        _currentHops.value = _currentHops.value + finalHop
                    }
                } else {
                    val info = emailPathwayEngine.analyzeEmailPathway(target)
                    _emailPathwayInfo.value = info
                    var hopCount = 0
                    for (rawHop in info.hops) {
                        hopCount++

                        if (!isPro && hopCount > 3) {
                            val lockedHop = HopNode(
                                hopIndex = hopCount,
                                ipAddress = "PRO.LOCKED",
                                hostname = "PRO VERSION FEATURE LOCKED",
                                rttMs = 0,
                                packetLossPercent = 100.0,
                                locationName = "Upgrade Required",
                                ispOrOrg = "Locked for Basic Users",
                                nodeType = NodeType.FIREWALL_BLOCKED,
                                securityStatus = SecurityStatus.ALERT,
                                details = "Email Pathway Hops > 3 locked in Basic Version. Switch user email to jssanjay369@gmail.com to unlock PRO VERSION!"
                            )
                            _currentHops.value = _currentHops.value + lockedHop
                            break
                        }

                        val (isBlocked, rule) = ipBlockerEngine.isIpBlocked(rawHop.ipAddress)
                        val finalHop = if (isBlocked && rule != null) {
                            ipBlockerEngine.recordBlockedLog(
                                sourceIp = rawHop.ipAddress,
                                target = target,
                                action = "EMAIL HOP INTERCEPTED",
                                ruleLabel = rule.label
                            )
                            _blockLogs.value = ipBlockerEngine.getLogs()
                            _blockRules.value = ipBlockerEngine.getRules()

                            HopNode(
                                hopIndex = rawHop.hopIndex,
                                ipAddress = rawHop.ipAddress,
                                hostname = "[BLOCKED BY IP FIREWALL]",
                                rttMs = 0,
                                packetLossPercent = 100.0,
                                locationName = "Blocked Node",
                                ispOrOrg = rule.label,
                                nodeType = NodeType.FIREWALL_BLOCKED,
                                securityStatus = SecurityStatus.ALERT,
                                details = "Blocked by Local IP Blocker Rule: ${rule.ipOrCidr} (${rule.label})"
                            )
                        } else {
                            rawHop
                        }

                        _currentHops.value = _currentHops.value + finalHop
                        kotlinx.coroutines.delay(350)
                    }
                }
                
                // Trace complete, save to DB
                saveCurrentTraceToDatabase(type, target)
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                _isTracing.value = false
            }
        }
    }

    fun stopTrace() {
        traceJob?.cancel()
        _isTracing.value = false
    }

    private suspend fun saveCurrentTraceToDatabase(type: TraceType, target: String) {
        val hops = _currentHops.value
        if (hops.isEmpty()) return

        val totalHops = hops.size
        val avgMs = hops.map { it.rttMs }.average()
        val loss = hops.map { it.packetLossPercent }.average()

        val record = TraceRecord(
            traceType = type.name,
            target = target,
            timestamp = System.currentTimeMillis(),
            totalHops = totalHops,
            avgLatencyMs = if (avgMs.isNaN()) 0.0 else avgMs,
            packetLossPercent = if (loss.isNaN()) 0.0 else loss,
            status = "COMPLETED",
            summaryText = "Traced $totalHops hops to $target with avg RTT ${String.format("%.1f", avgMs)}ms"
        )

        val hopRecords = hops.map { h ->
            HopDetailRecord(
                traceRecordId = 0,
                hopIndex = h.hopIndex,
                ipAddress = h.ipAddress,
                hostname = h.hostname,
                rttMs = h.rttMs,
                packetLossPercent = h.packetLossPercent,
                locationName = h.locationName,
                ispOrOrg = h.ispOrOrg,
                nodeType = h.nodeType.name,
                securityStatus = h.securityStatus.name,
                details = h.details
            )
        }

        repository.saveTraceRun(record, hopRecords)
    }

    fun selectHop(hop: HopNode?) {
        _selectedHopForDetail.value = hop
    }

    fun loadTraceHopsFromHistory(traceId: Int) {
        viewModelScope.launch {
            repository.getHopsForTrace(traceId).collect { hopRecords ->
                _historyHops.value = hopRecords
                // Map to HopNodes for visualizer
                _currentHops.value = hopRecords.map { hr ->
                    HopNode(
                        hopIndex = hr.hopIndex,
                        ipAddress = hr.ipAddress,
                        hostname = hr.hostname,
                        rttMs = hr.rttMs,
                        packetLossPercent = hr.packetLossPercent,
                        locationName = hr.locationName,
                        ispOrOrg = hr.ispOrOrg,
                        nodeType = try { NodeType.valueOf(hr.nodeType) } catch (e: Exception) { NodeType.UNKNOWN },
                        securityStatus = try { SecurityStatus.valueOf(hr.securityStatus) } catch (e: Exception) { SecurityStatus.NEUTRAL },
                        details = hr.details
                    )
                }
            }
        }
    }

    fun deleteHistoryTrace(traceId: Int) {
        viewModelScope.launch {
            repository.deleteTrace(traceId)
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearHistory()
        }
    }

    fun generateExportReport() {
        if (!_isProUser.value) {
            _exportText.value = "=== PRO FEATURE LOCKED ===\n\nDiagnostic Export is exclusively available for PRO VERSION users.\nAccount Email: ${currentUserEmail.value}\nStatus: BASIC (LOCKED)\n\nPlease switch account email to jssanjay369@gmail.com to unlock full Pro diagnostic exports!"
            return
        }

        val hops = _currentHops.value
        val type = _activeTraceType.value
        val target = if (type == TraceType.PHONE_NETWORK) targetPhoneHost.value else targetEmailInput.value
        val dev = _deviceNetworkInfo.value

        val sb = StringBuilder()
        sb.appendLine("=== DIGITAL TRACEROUTE PRO DIAGNOSTIC REPORT ===")
        sb.appendLine("Account: ${currentUserEmail.value} [PRO VERSION UNLOCKED]")
        sb.appendLine("Type: ${type.name}")
        sb.appendLine("Target: $target")
        sb.appendLine("Timestamp: ${java.util.Date()}")
        sb.appendLine("Local Phone IP: ${dev.localIp} (${dev.connectionType})")
        sb.appendLine("Gateway IP: ${dev.gatewayIp}")
        sb.appendLine("Public IP: ${dev.publicIp} [${dev.cityRegionCountry}]")
        sb.appendLine("Carrier/ISP: ${dev.carrierOrIsp}")
        sb.appendLine("IP Blocker Shield: ${if (_isIpBlockerActive.value) "ACTIVE" else "DISABLED"}")
        sb.appendLine("Trace Connection Shield: ${if (_isTraceConnectionBlockerActive.value) "ACTIVE" else "DISABLED"}")
        sb.appendLine("=========================================")
        sb.appendLine("HOP | IP ADDRESS | HOSTNAME | RTT (ms) | LOSS% | LOCATION / ISP")
        sb.appendLine("---------------------------------------------------------")
        for (h in hops) {
            sb.appendLine(
                String.format(
                    "#%-2d | %-15s | %-20s | %-4dms | %-3.1f%% | %s",
                    h.hopIndex,
                    h.ipAddress,
                    if (h.hostname.length > 20) h.hostname.take(17) + "..." else h.hostname,
                    h.rttMs,
                    h.packetLossPercent,
                    "${h.locationName} (${h.ispOrOrg})"
                )
            )
        }
        
        val emailInfo = _emailPathwayInfo.value
        if (type == TraceType.EMAIL_PATHWAY && emailInfo != null) {
            sb.appendLine("=========================================")
            sb.appendLine("EMAIL MX & SECURITY RESOLUTION:")
            sb.appendLine("Domain: ${emailInfo.domain}")
            sb.appendLine("Security Score: ${emailInfo.overallSecurityScore}/100")
            sb.appendLine("TLS Support: ${emailInfo.tlsSupport}")
            sb.appendLine("SPF Record: ${emailInfo.spfRecord}")
            sb.appendLine("DMARC Record: ${emailInfo.dmarcRecord}")
            for (mx in emailInfo.mxServers) {
                sb.appendLine("MX Priority ${mx.priority}: ${mx.host} (${mx.ipAddress}) - ${mx.latencyMs}ms")
            }
        }
        sb.appendLine("=========================================")

        _exportText.value = sb.toString()
    }

    fun dismissExportDialog() {
        _exportText.value = null
    }
}

