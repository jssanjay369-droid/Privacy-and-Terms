package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AlternateEmail
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.HopDetailDialog
import com.example.ui.theme.AmberYellow
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.SurfaceDarkCard
import com.example.ui.theme.SurfaceDarkElevated
import com.example.ui.viewmodel.TraceType
import com.example.ui.viewmodel.TracerouteViewModel

@Composable
fun EmailPathwaysScreen(
    viewModel: TracerouteViewModel
) {
    val isTracing by viewModel.isTracing.collectAsState()
    val emailInput by viewModel.targetEmailInput.collectAsState()
    val emailInfo by viewModel.emailPathwayInfo.collectAsState()
    val currentHops by viewModel.currentHops.collectAsState()
    val selectedHop by viewModel.selectedHopForDetail.collectAsState()

    val sampleEmails = listOf(
        "jssanjay369@gmail.com",
        "alex@company.com",
        "user@outlook.com",
        "dev@proton.me"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            // 1. Email Address Input Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceDarkCard)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(CyberCyan.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AlternateEmail,
                                    contentDescription = "Email",
                                    tint = CyberCyan,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "TRACE EMAIL DIGITAL PATHWAY",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = "Inspect MX server hops & SPF/DMARC auth route",
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = emailInput,
                                onValueChange = { viewModel.targetEmailInput.value = it },
                                placeholder = { Text("Enter email address", color = Color.Gray) },
                                singleLine = true,
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.AlternateEmail,
                                        contentDescription = "Email Input",
                                        tint = ElectricBlue
                                    )
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("email_target_input"),
                                shape = RoundedCornerShape(14.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = CyberCyan,
                                    unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedContainerColor = SurfaceDarkElevated,
                                    unfocusedContainerColor = SurfaceDarkElevated
                                )
                            )

                            Spacer(modifier = Modifier.width(10.dp))

                            Button(
                                onClick = {
                                    viewModel.setTraceType(TraceType.EMAIL_PATHWAY)
                                    if (isTracing) viewModel.stopTrace() else viewModel.startTrace()
                                },
                                modifier = Modifier
                                    .height(54.dp)
                                    .testTag("start_email_trace_btn"),
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isTracing) CrimsonRed else CyberCyan,
                                    contentColor = Color.Black
                                )
                            ) {
                                Icon(
                                    imageVector = if (isTracing) Icons.Default.Stop else Icons.Default.PlayArrow,
                                    contentDescription = if (isTracing) "Stop Trace" else "Trace Email",
                                    tint = if (isTracing) Color.White else Color.Black
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isTracing) "STOP" else "TRACE",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = if (isTracing) Color.White else Color.Black
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Quick Sample Emails
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(sampleEmails) { sample ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(20.dp))
                                        .background(
                                            if (emailInput == sample) CyberCyan.copy(alpha = 0.2f) else SurfaceDarkElevated
                                        )
                                        .border(
                                            1.dp,
                                            if (emailInput == sample) CyberCyan else Color.Transparent,
                                            RoundedCornerShape(20.dp)
                                        )
                                        .clickable { viewModel.targetEmailInput.value = sample }
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = sample,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = if (emailInput == sample) CyberCyan else Color.LightGray
                                    )
                                }
                            }
                        }

                        AnimatedVisibility(visible = isTracing) {
                            Column(modifier = Modifier.padding(top = 12.dp)) {
                                LinearProgressIndicator(
                                    modifier = Modifier.fillMaxWidth(),
                                    color = CyberCyan,
                                    trackColor = SurfaceDarkElevated
                                )
                                Text(
                                    text = "Resolving MX records & SPF/DMARC route for $emailInput...",
                                    fontSize = 11.sp,
                                    color = CyberCyan,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }

            // 2. Resolved Domain Security & MX Details
            emailInfo?.let { info ->
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = SurfaceDarkCard)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Dns,
                                        contentDescription = "Domain MX",
                                        tint = ElectricBlue
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "DOMAIN MX & ROUTE AUTH",
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        fontSize = 13.sp
                                    )
                                }

                                // Security Score Badge
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(EmeraldGreen.copy(alpha = 0.15f))
                                        .border(1.dp, EmeraldGreen, RoundedCornerShape(12.dp))
                                        .padding(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = "Route Security: ${info.overallSecurityScore}/100",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = EmeraldGreen
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // SPF and DMARC badges
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                AuthBadge(
                                    label = "SPF RECORD",
                                    isValid = info.isSpfValid,
                                    text = if (info.isSpfValid) "PASS (v=spf1)" else "WARNING",
                                    modifier = Modifier.weight(1f)
                                )
                                AuthBadge(
                                    label = "DMARC POLICY",
                                    isValid = info.isDmarcValid,
                                    text = if (info.isDmarcValid) "PROTECTED (DMARC1)" else "NEUTRAL",
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Primary MX Server Node
                            if (info.mxServers.isNotEmpty()) {
                                val primaryMx = info.mxServers.first()
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(SurfaceDarkElevated)
                                        .padding(12.dp)
                                ) {
                                    Column {
                                        Text(
                                            text = "PRIMARY MX HOST (PRIORITY ${primaryMx.priority})",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = CyberCyan
                                        )
                                        Text(
                                            text = primaryMx.host,
                                            fontSize = 14.sp,
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                        Text(
                                            text = "${primaryMx.provider} • IP: ${primaryMx.ipAddress} • RTT: ${primaryMx.latencyMs}ms",
                                            fontSize = 11.sp,
                                            color = Color.Gray,
                                            modifier = Modifier.padding(top = 2.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }

            // 3. Reliable Email Pathway Hop Data List
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "EMAIL DIGITAL PATHWAY HOPS",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "${currentHops.size} Nodes Traversed",
                        fontSize = 11.sp,
                        color = CyberCyan
                    )
                }
            }

            if (currentHops.isEmpty() && !isTracing) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(SurfaceDarkCard),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "No email pathway traced yet",
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "Enter an email and tap TRACE to inspect the network pathway",
                                color = Color.DarkGray,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }
                }
            } else {
                items(currentHops, key = { it.hopIndex }) { hop ->
                    HopItemCard(
                        hop = hop,
                        onClick = { viewModel.selectHop(hop) }
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }
        }

        selectedHop?.let { hop ->
            HopDetailDialog(
                hop = hop,
                onDismiss = { viewModel.selectHop(null) }
            )
        }
    }
}

@Composable
private fun AuthBadge(
    label: String,
    isValid: Boolean,
    text: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(SurfaceDarkElevated)
            .border(
                1.dp,
                if (isValid) EmeraldGreen.copy(alpha = 0.4f) else AmberYellow.copy(alpha = 0.4f),
                RoundedCornerShape(12.dp)
            )
            .padding(10.dp)
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (isValid) Icons.Default.CheckCircle else Icons.Default.Warning,
                    contentDescription = label,
                    tint = if (isValid) EmeraldGreen else AmberYellow,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = label,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Gray
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = text,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = if (isValid) EmeraldGreen else AmberYellow
            )
        }
    }
}
