package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.network.HopNode
import com.example.ui.components.DeviceNetworkHeader
import com.example.ui.components.HopDetailDialog
import com.example.ui.theme.AmberYellow
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.SurfaceDarkCard
import com.example.ui.theme.SurfaceDarkElevated
import com.example.ui.viewmodel.TracerouteViewModel

@Composable
fun PhoneTracerouteScreen(
    viewModel: TracerouteViewModel
) {
    val deviceInfo by viewModel.deviceNetworkInfo.collectAsState()
    val isTracing by viewModel.isTracing.collectAsState()
    val targetHost by viewModel.targetPhoneHost.collectAsState()
    val currentHops by viewModel.currentHops.collectAsState()
    val selectedHop by viewModel.selectedHopForDetail.collectAsState()

    val presets = listOf("google.com", "8.8.8.8", "cloudflare.com", "1.1.1.1", "amazon.com")

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            // 1. Device Network Header
            item {
                DeviceNetworkHeader(
                    info = deviceInfo,
                    onRefresh = { viewModel.refreshDeviceInfo() }
                )
                Spacer(modifier = Modifier.height(16.dp))
            }

            // 2. Input Box & Action Button
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceDarkCard)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "TRACE PHONE NETWORK PATHWAYS",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyberCyan,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = targetHost,
                                onValueChange = { viewModel.targetPhoneHost.value = it },
                                placeholder = { Text("Enter IP or domain (e.g. 8.8.8.8)", color = Color.Gray) },
                                singleLine = true,
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.Search,
                                        contentDescription = "Search Target",
                                        tint = ElectricBlue
                                    )
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("phone_target_input"),
                                shape = RoundedCornerShape(14.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = CyberCyan,
                                    unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedContainerColor = SurfaceDarkElevated,
                                    unfocusedContainerColor = SurfaceDarkElevated
                                )
                            )

                            Spacer(modifier = Modifier.width(10.dp))

                            Button(
                                onClick = {
                                    if (isTracing) viewModel.stopTrace() else viewModel.startTrace()
                                },
                                modifier = Modifier
                                    .height(54.dp)
                                    .testTag("start_phone_trace_btn"),
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isTracing) CrimsonRed else CyberCyan,
                                    contentColor = Color.Black
                                )
                            ) {
                                Icon(
                                    imageVector = if (isTracing) Icons.Default.Stop else Icons.Default.PlayArrow,
                                    contentDescription = if (isTracing) "Stop Trace" else "Start Trace",
                                    tint = if (isTracing) Color.White else Color.Black
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isTracing) "STOP" else "TRACE",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = if (isTracing) Color.White else Color.Black
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Quick Presets
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(presets) { preset ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(20.dp))
                                        .background(
                                            if (targetHost == preset) CyberCyan.copy(alpha = 0.2f) else SurfaceDarkElevated
                                        )
                                        .border(
                                            1.dp,
                                            if (targetHost == preset) CyberCyan else Color.Transparent,
                                            RoundedCornerShape(20.dp)
                                        )
                                        .clickable { viewModel.targetPhoneHost.value = preset }
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = preset,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = if (targetHost == preset) CyberCyan else Color.LightGray
                                    )
                                }
                            }
                        }

                        // Progress bar during active trace
                        AnimatedVisibility(visible = isTracing) {
                            Column(modifier = Modifier.padding(top = 12.dp)) {
                                LinearProgressIndicator(
                                    modifier = Modifier.fillMaxWidth(),
                                    color = CyberCyan,
                                    trackColor = SurfaceDarkElevated
                                )
                                Text(
                                    text = "Probing network hops to $targetHost...",
                                    fontSize = 11.sp,
                                    color = CyberCyan,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            // 3. Stats Summary Bar if hops present
            if (currentHops.isNotEmpty()) {
                item {
                    val avgRtt = currentHops.map { it.rttMs }.average()
                    val maxRtt = currentHops.maxOfOrNull { it.rttMs } ?: 0

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = SurfaceDarkCard)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            SummaryStatItem(label = "Total Hops", value = "${currentHops.size}")
                            SummaryStatItem(
                                label = "Avg Latency",
                                value = "${String.format("%.0f", avgRtt)} ms",
                                color = if (avgRtt < 50) EmeraldGreen else AmberYellow
                            )
                            SummaryStatItem(
                                label = "Max Latency",
                                value = "$maxRtt ms",
                                color = if (maxRtt < 100) EmeraldGreen else CrimsonRed
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }

            // 4. Reliable Data List Header
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "RELIABLE HOP DATA LIST",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "${currentHops.size} Nodes Resolved",
                        fontSize = 11.sp,
                        color = ElectricBlue
                    )
                }
            }

            // 5. Hop Items
            if (currentHops.isEmpty() && !isTracing) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(SurfaceDarkCard),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "No active trace pathway yet",
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "Press TRACE above to begin live network discovery",
                                color = Color.DarkGray,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }
                }
            } else {
                items(currentHops, key = { it.hopIndex }) { hop ->
                    HopItemCard(
                        hop = hop,
                        onClick = { viewModel.selectHop(hop) }
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }
        }

        // Detail Popup Dialog
        selectedHop?.let { hop ->
            HopDetailDialog(
                hop = hop,
                onDismiss = { viewModel.selectHop(null) }
            )
        }
    }
}

@Composable
fun HopItemCard(
    hop: HopNode,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("hop_item_${hop.hopIndex}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDarkCard)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Hop Index Badge
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(
                        when {
                            hop.rttMs < 40 -> EmeraldGreen.copy(alpha = 0.2f)
                            hop.rttMs < 100 -> AmberYellow.copy(alpha = 0.2f)
                            else -> CrimsonRed.copy(alpha = 0.2f)
                        }
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "${hop.hopIndex}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = when {
                        hop.rttMs < 40 -> EmeraldGreen
                        hop.rttMs < 100 -> AmberYellow
                        else -> CrimsonRed
                    }
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            // IP & Host details
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = hop.ipAddress,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = Color.White,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(SurfaceDarkElevated)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = hop.nodeType.name,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = ElectricBlue
                        )
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${hop.hostname} • ${hop.locationName}",
                    fontSize = 11.sp,
                    color = Color.Gray,
                    maxLines = 1
                )
            }

            // Latency indicator
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${hop.rttMs} ms",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = when {
                        hop.rttMs < 40 -> EmeraldGreen
                        hop.rttMs < 100 -> AmberYellow
                        else -> CrimsonRed
                    }
                )
                Text(
                    text = "${hop.packetLossPercent}% Loss",
                    fontSize = 10.sp,
                    color = Color.Gray
                )
            }

            Spacer(modifier = Modifier.width(6.dp))
            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = "Details",
                tint = Color.Gray,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
private fun SummaryStatItem(
    label: String,
    value: String,
    color: Color = Color.White
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = label.uppercase(),
            fontSize = 10.sp,
            color = Color.Gray,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = value,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = color,
            modifier = Modifier.padding(top = 2.dp)
        )
    }
}
