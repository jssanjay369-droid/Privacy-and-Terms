package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.HopDetailDialog
import com.example.ui.components.NetworkPathwayCanvas
import com.example.ui.theme.AmberYellow
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.SurfaceDarkCard
import com.example.ui.theme.SurfaceDarkElevated
import com.example.ui.viewmodel.TraceType
import com.example.ui.viewmodel.TracerouteViewModel

@Composable
fun PathwayVisualizerScreen(
    viewModel: TracerouteViewModel
) {
    val hops by viewModel.currentHops.collectAsState()
    val isTracing by viewModel.isTracing.collectAsState()
    val activeType by viewModel.activeTraceType.collectAsState()
    val targetPhone by viewModel.targetPhoneHost.collectAsState()
    val targetEmail by viewModel.targetEmailInput.collectAsState()
    val selectedHop by viewModel.selectedHopForDetail.collectAsState()

    val currentTarget = if (activeType == TraceType.PHONE_NETWORK) targetPhone else targetEmail

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            // Header Bar
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceDarkCard)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "REAL-TIME PATHWAY VISUALIZER",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = CyberCyan,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "Target: $currentTarget (${hops.size} Nodes)",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }

                        Button(
                            onClick = {
                                if (isTracing) viewModel.stopTrace() else viewModel.startTrace()
                            },
                            modifier = Modifier
                                .height(44.dp)
                                .testTag("visualizer_trace_toggle_btn"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isTracing) CrimsonRed else CyberCyan,
                                contentColor = Color.Black
                            )
                        ) {
                            Icon(
                                imageVector = if (isTracing) Icons.Default.Stop else Icons.Default.PlayArrow,
                                contentDescription = if (isTracing) "Stop" else "Start",
                                tint = if (isTracing) Color.White else Color.Black,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isTracing) "STOP" else "TRACE",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = if (isTracing) Color.White else Color.Black
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }

            // Interactive Pathway Canvas
            item {
                NetworkPathwayCanvas(
                    hops = hops,
                    onNodeClick = { hop -> viewModel.selectHop(hop) }
                )
                Spacer(modifier = Modifier.height(16.dp))
            }

            // Canvas Controls & Legend Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceDarkCard)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = "Legend",
                                tint = ElectricBlue
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "NODE & LATENCY LEGEND",
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 12.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            LegendItem(color = CyberCyan, label = "Device / Phone", modifier = Modifier.weight(1f))
                            LegendItem(color = ElectricBlue, label = "Gateway Router", modifier = Modifier.weight(1f))
                            LegendItem(color = Color(0xFFA855F7), label = "MX Email Server", modifier = Modifier.weight(1f))
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            LegendItem(color = EmeraldGreen, label = "< 50ms (Optimal)", modifier = Modifier.weight(1f))
                            LegendItem(color = AmberYellow, label = "50 - 150ms (Mid)", modifier = Modifier.weight(1f))
                            LegendItem(color = CrimsonRed, label = "> 150ms / Dropped", modifier = Modifier.weight(1f))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }

            // Selected Hop Quick Summary below canvas
            if (hops.isNotEmpty()) {
                item {
                    Text(
                        text = "TAP ANY CANVAS NODE TO INSPECT FULL TELEMETRY",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }
            }
        }

        selectedHop?.let { hop ->
            HopDetailDialog(
                hop = hop,
                onDismiss = { viewModel.selectHop(null) }
            )
        }
    }
}

@Composable
private fun LegendItem(
    color: Color,
    label: String,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(SurfaceDarkElevated)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = FontWeight.Medium,
            color = Color.LightGray
        )
    }
}
