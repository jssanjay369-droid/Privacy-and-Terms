package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.network.HopNode
import com.example.data.network.NodeType
import com.example.ui.theme.AmberYellow
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DeepNavyBg
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.SurfaceDarkCard
import com.example.ui.theme.SurfaceDarkElevated

@Composable
fun NetworkPathwayCanvas(
    hops: List<HopNode>,
    onNodeClick: (HopNode) -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulsePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulsePhase"
    )

    val textMeasurer = rememberTextMeasurer()

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(380.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        DeepNavyBg,
                        SurfaceDarkCard
                    )
                )
            )
            .border(1.dp, CyberCyan.copy(alpha = 0.25f), RoundedCornerShape(20.dp))
            .testTag("network_pathway_canvas")
    ) {
        if (hops.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp),
                contentAlignment = androidx.compose.ui.Alignment.Center
            ) {
                Column(horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
                    Text(
                        text = "NETWORK PATHWAY CANVAS",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = ElectricBlue,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Start a trace to visualize live network pathways",
                        fontSize = 13.sp,
                        color = Color.Gray,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }
            }
        } else {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(hops) {
                        detectTapGestures { tapOffset ->
                            // Calculate node touch hit targets
                            val width = size.width.toFloat()
                            val height = size.height.toFloat()
                            val nodeRadius = 24.dp.toPx()

                            val points = calculateNodeCoordinates(hops.size, width, height)
                            for (i in hops.indices) {
                                val pt = points[i]
                                val dx = tapOffset.x - pt.x
                                val dy = tapOffset.y - pt.y
                                if (dx * dx + dy * dy <= (nodeRadius * 1.5f) * (nodeRadius * 1.5f)) {
                                    onNodeClick(hops[i])
                                    break
                                }
                            }
                        }
                    }
            ) {
                val canvasWidth = size.width
                val canvasHeight = size.height

                val nodePoints = calculateNodeCoordinates(hops.size, canvasWidth, canvasHeight)

                // 1. Draw connection lines between nodes
                for (i in 0 until nodePoints.size - 1) {
                    val p1 = nodePoints[i]
                    val p2 = nodePoints[i + 1]

                    val path = Path().apply {
                        moveTo(p1.x, p1.y)
                        // Smooth bezier curve between nodes
                        val controlX = (p1.x + p2.x) / 2
                        val controlY = if (i % 2 == 0) p1.y - 30f else p1.y + 30f
                        quadraticTo(controlX, controlY, p2.x, p2.y)
                    }

                    // Base pathway line
                    drawPath(
                        path = path,
                        color = ElectricBlue.copy(alpha = 0.4f),
                        style = Stroke(
                            width = 3.dp.toPx(),
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 10f), 0f)
                        )
                    )

                    // Animated pulse dot along the path
                    val lerpX = p1.x + (p2.x - p1.x) * pulsePhase
                    val lerpY = p1.y + (p2.y - p1.y) * pulsePhase
                    drawCircle(
                        color = CyberCyan,
                        radius = 6.dp.toPx(),
                        center = Offset(lerpX, lerpY)
                    )
                    drawCircle(
                        color = CyberCyan.copy(alpha = 0.3f),
                        radius = 12.dp.toPx(),
                        center = Offset(lerpX, lerpY)
                    )
                }

                // 2. Draw nodes
                for (i in hops.indices) {
                    val hop = hops[i]
                    val pt = nodePoints[i]

                    val nodeColor = when {
                        hop.nodeType == NodeType.DEVICE -> CyberCyan
                        hop.nodeType == NodeType.GATEWAY -> ElectricBlue
                        hop.nodeType == NodeType.MX_SERVER -> Color(0xFFA855F7) // Purple
                        hop.nodeType == NodeType.STORAGE -> EmeraldGreen
                        hop.rttMs > 150 -> CrimsonRed
                        hop.rttMs > 60 -> AmberYellow
                        else -> EmeraldGreen
                    }

                    // Outer glowing aura
                    drawCircle(
                        color = nodeColor.copy(alpha = 0.15f),
                        radius = 28.dp.toPx(),
                        center = pt
                    )

                    // Node outer ring
                    drawCircle(
                        color = nodeColor,
                        radius = 18.dp.toPx(),
                        center = pt,
                        style = Stroke(width = 3.dp.toPx())
                    )

                    // Node core
                    drawCircle(
                        color = SurfaceDarkCard,
                        radius = 15.dp.toPx(),
                        center = pt
                    )

                    // Draw Hop # inside node core
                    val hopText = "#${hop.hopIndex}"
                    val textLayout = textMeasurer.measure(
                        text = hopText,
                        style = TextStyle(
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    )
                    drawText(
                        textLayoutResult = textLayout,
                        topLeft = Offset(
                            pt.x - (textLayout.size.width / 2f),
                            pt.y - (textLayout.size.height / 2f)
                        )
                    )

                    // Draw Label & RTT badge below node
                    val ipLabel = if (hop.ipAddress.length > 13) hop.ipAddress.take(12) + ".." else hop.ipAddress
                    val labelLayout = textMeasurer.measure(
                        text = ipLabel,
                        style = TextStyle(
                            color = Color.LightGray,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            fontFamily = FontFamily.Monospace
                        )
                    )
                    drawText(
                        textLayoutResult = labelLayout,
                        topLeft = Offset(
                            pt.x - (labelLayout.size.width / 2f),
                            pt.y + 22.dp.toPx()
                        )
                    )

                    val rttLabel = "${hop.rttMs}ms"
                    val rttLayout = textMeasurer.measure(
                        text = rttLabel,
                        style = TextStyle(
                            color = nodeColor,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    drawText(
                        textLayoutResult = rttLayout,
                        topLeft = Offset(
                            pt.x - (rttLayout.size.width / 2f),
                            pt.y + 34.dp.toPx()
                        )
                    )
                }
            }
        }
    }
}

/**
 * Calculates responsive node coordinates in a zigzag / snake pathway across the canvas.
 */
private fun calculateNodeCoordinates(
    count: Int,
    width: Float,
    height: Float
): List<Offset> {
    val list = mutableListOf<Offset>()
    if (count <= 0) return list

    val paddingX = 48f
    val paddingY = 50f
    val usableWidth = width - (paddingX * 2)
    val usableHeight = height - (paddingY * 2)

    val maxCols = if (count <= 4) count else 4
    val rows = Math.ceil(count.toDouble() / maxCols).toInt().coerceAtLeast(1)

    for (i in 0 until count) {
        val row = i / maxCols
        val colInRow = i % maxCols

        // Alternate row directions for snake pathway
        val actualCol = if (row % 2 == 0) colInRow else (maxCols - 1 - colInRow)

        val x = paddingX + (usableWidth / (maxCols - 1).coerceAtLeast(1)) * actualCol
        val y = paddingY + (usableHeight / (rows - 1).coerceAtLeast(1)) * row

        list.add(Offset(x, y))
    }

    return list
}
