package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.network.IpBlockerEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("TraceRoute", appName)
  }

  @Test
  fun `verify ip blocker engine filtering`() {
    val engine = IpBlockerEngine()
    val (isBlocked, rule) = engine.isIpBlocked("185.220.101.5")
    assertTrue(isBlocked)
    assertEquals("Known Malicious Tor Exit Node", rule?.label)

    val (isBlockedUnlisted, _) = engine.isIpBlocked("8.8.8.8")
    assertFalse(isBlockedUnlisted)
  }
}

